variable "project"             { type = string }
variable "location"            { type = string }
variable "resource_group_name" { type = string }