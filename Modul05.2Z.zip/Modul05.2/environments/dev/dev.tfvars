kortnavn   = "vbs05"
project    = "iac-dev"
location   = "norwayeast"