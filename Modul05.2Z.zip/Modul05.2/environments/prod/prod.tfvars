kortnavn   = "vbs05"
project    = "iac-prod"
location   = "norwayeast"