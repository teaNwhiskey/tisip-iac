module "network" {
  source              = "../modules/network"
  project             = var.project
  location            = var.location
  resource_group_name = azurerm_resource_group.main.name
}